-- testa se existe valore menores que 0 (negativos)
select *
    from tb_10_compradores
    where vendas_totais < 0